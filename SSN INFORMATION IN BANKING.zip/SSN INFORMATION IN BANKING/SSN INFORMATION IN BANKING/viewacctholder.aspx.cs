﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class viewacctholder : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                SqlCommand cmd1 = new SqlCommand("select * from accountholder", conc);
                conc.Open();
                DataTable dt1 = new DataTable();
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                dt1.Load(sdr1);
                conc.Close();
                if (dt1.Rows.Count >= 0)
                {
                    DataList1.DataSource = dt1;
                    DataList1.DataBind();
                }
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text!="")
            {
                SqlCommand cmd1 = new SqlCommand("select * from accountholder where ssn_number='"+TextBox1.Text+"' or acct_no='"+TextBox1.Text+"'", conc);
                conc.Open();
                DataTable dt1 = new DataTable();
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                dt1.Load(sdr1);
                conc.Close();
                if (dt1.Rows.Count >= 0)
                {
                    DataList1.DataSource = dt1;
                    DataList1.DataBind();
                }
            }
            else
            {

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Label lbl = (Label)btn.NamingContainer.FindControl("Label9");

            if (lbl.Text != "")
            {
                SqlCommand cmd1 = new SqlCommand("delete from accountholder where acct_no='" + lbl.Text + "'", conc);
                conc.Open();
                cmd1.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Account Holder detail Deleted');window.location='viewacctholder.aspx' </script>");
            }
        }
    }
}