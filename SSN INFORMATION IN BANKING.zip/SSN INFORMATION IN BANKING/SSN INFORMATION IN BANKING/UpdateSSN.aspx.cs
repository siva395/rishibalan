﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class UpdateSSN : System.Web.UI.Page
    {
        public static string ssnno;
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            ssnno= Request.QueryString["ssn"];
            string query = "select * from ssn_basic where ssn_number='"+ssnno+"'";
            SqlCommand cmd = new SqlCommand(query,conc);
            conc.Open();
            DataTable dt = new DataTable();
            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            txtemail.Value = dt.Rows[0]["email"].ToString();
            txtmob.Value = dt.Rows[0]["mobile"].ToString();
            txtaddress.Value = dt.Rows[0]["address"].ToString();
            txtcity.Value = dt.Rows[0]["city"].ToString();
            txtstate.Value = dt.Rows[0]["state"].ToString();
            txtpin.Value = dt.Rows[0]["pincode"].ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           string v= txtaddress.Value;
        }
    }
}