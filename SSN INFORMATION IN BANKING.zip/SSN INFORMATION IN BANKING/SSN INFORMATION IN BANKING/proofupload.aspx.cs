﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class proofupload : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CheckBox5_CheckedChanged(object sender, EventArgs e)
        {
            
                TextBox6.Enabled = true;
            
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload5.HasFile && TextBox6.Text!="")
            {
                SqlCommand checkdata = new SqlCommand("select count(*) from ssn_proof where ssn_number='" + TextBox1.Text + "' and proof_category='" + CheckBox5.Text + "'", conc);
                conc.Open();
                int count = Convert.ToInt32(checkdata.ExecuteScalar());
                conc.Close();
                if (count == 0)
                {
                    FileUpload5.SaveAs(Server.MapPath("~/Proof/") + Path.GetFileName(FileUpload5.FileName));
                    SqlCommand cmd = new SqlCommand("insert into ssn_proof(ssn_number,proof_category,card_no,photo)values('" + TextBox1.Text + "','" + CheckBox5.Text + "','" + TextBox6.Text + "','" + FileUpload5.FileName + "')", conc);
                    conc.Open();
                    cmd.ExecuteNonQuery();
                    conc.Close();
                    Response.Write("<script>alert('Proof Uploaded');window.location='proofupload.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Proof Already Exist...');window.location='proofupload.aspx'</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Enter Driving License no. and Upload proof');window.location='proofupload.aspx'</script>");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (FileUpload3.HasFile && TextBox4.Text!="")
            {
                SqlCommand checkdata = new SqlCommand("select count(*) from ssn_proof where ssn_number='"+TextBox1.Text+"' and proof_category='"+CheckBox4.Text+"'",conc);
                conc.Open();
                int count = Convert.ToInt32(checkdata.ExecuteScalar());
                conc.Close();
                if (count == 0)
                {
                    FileUpload3.SaveAs(Server.MapPath("~/Proof/") + Path.GetFileName(FileUpload3.FileName));

                    SqlCommand cmd = new SqlCommand("insert into ssn_proof(ssn_number,proof_category,card_no,photo)values('" + TextBox1.Text + "','" + CheckBox4.Text + "','" + TextBox4.Text + "','" + FileUpload3.FileName + "')", conc);
                    conc.Open();
                    cmd.ExecuteNonQuery();
                    conc.Close();
                    Response.Write("<script>alert('Proof Uploaded');window.location='proofupload.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Proof Already Exist...');window.location='proofupload.aspx'</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Enter Passport no. and Upload proof');window.location='proofupload.aspx'</script>");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            if (FileUpload4.HasFile && TextBox5.Text!="")
            {
                SqlCommand checkdata = new SqlCommand("select count(*) from ssn_proof where ssn_number='" + TextBox1.Text + "' and proof_category='" + CheckBox3.Text + "'", conc);
                conc.Open();
                int count = Convert.ToInt32(checkdata.ExecuteScalar());
                conc.Close();
                if (count == 0)
                {
                    FileUpload4.SaveAs(Server.MapPath("~/Proof/") + Path.GetFileName(FileUpload4.FileName));
                    SqlCommand cmd = new SqlCommand("insert into ssn_proof(ssn_number,proof_category,card_no,photo)values('" + TextBox1.Text + "','" + CheckBox3.Text + "','" + TextBox5.Text + "','" + FileUpload4.FileName + "')", conc);
                    conc.Open();
                    cmd.ExecuteNonQuery();
                    conc.Close();
                    Response.Write("<script>alert('Proof Uploaded');window.location='proofupload.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Proof Already Exist...');window.location='proofupload.aspx'</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Enter Pan no. and Upload proof');window.location='proofupload.aspx'</script>");
            }
        }

        protected void CheckBox4_CheckedChanged(object sender, EventArgs e)
        {
            TextBox4.Enabled = true;
        }

        protected void CheckBox3_CheckedChanged(object sender, EventArgs e)
        {
            TextBox5.Enabled = true;
        }

        protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            TextBox3.Enabled = true;
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            TextBox2.Enabled = true;
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile && TextBox2.Text != "")
            {
                SqlCommand checkdata = new SqlCommand("select count(*) from ssn_proof where ssn_number='" + TextBox1.Text + "' and proof_category='" + CheckBox1.Text + "'", conc);
                conc.Open();
                int count = Convert.ToInt32(checkdata.ExecuteScalar());
                conc.Close();
                if (count == 0)
                {
                    FileUpload1.SaveAs(Server.MapPath("~/Proof/") + Path.GetFileName(FileUpload1.FileName));
                    SqlCommand cmd = new SqlCommand("insert into ssn_proof(ssn_number,proof_category,card_no,photo)values('" + TextBox1.Text + "','" + CheckBox1.Text + "','" + TextBox2.Text + "','" + FileUpload1.FileName + "')", conc);
                    conc.Open();
                    cmd.ExecuteNonQuery();
                    conc.Close();
                    Response.Write("<script>alert('Proof Uploaded');window.location='proofupload.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Proof Already Exist...');window.location='proofupload.aspx'</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Enter Adhaar no. and Upload proof');window.location='proofupload.aspx'</script>");
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            if (FileUpload2.HasFile && TextBox3.Text != "")
            {
                SqlCommand checkdata = new SqlCommand("select count(*) from ssn_proof where ssn_number='" + TextBox1.Text + "' and proof_category='" + CheckBox2.Text + "'", conc);
                conc.Open();
                int count = Convert.ToInt32(checkdata.ExecuteScalar());
                conc.Close();
                if (count == 0)
                {
                    FileUpload2.SaveAs(Server.MapPath("~/Proof/") + Path.GetFileName(FileUpload2.FileName));
                    SqlCommand cmd = new SqlCommand("insert into ssn_proof(ssn_number,proof_category,card_no,photo)values('" + TextBox1.Text + "','" + CheckBox2.Text + "','" + TextBox3.Text + "','" + FileUpload2.FileName + "')", conc);
                    conc.Open();
                    cmd.ExecuteNonQuery();
                    conc.Close();
                    Response.Write("<script>alert('Proof Uploaded');window.location='proofupload.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Proof Already Exist...');window.location='proofupload.aspx'</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Enter Voter Id and Upload proof');window.location='proofupload.aspx'</script>");
            }
        }
    }
}