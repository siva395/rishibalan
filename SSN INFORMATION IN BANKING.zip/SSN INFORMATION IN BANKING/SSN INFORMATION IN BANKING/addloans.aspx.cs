﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class addloans : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlCommand cmd = new SqlCommand("select *,('/SSN/')+photo as img from loantype", conc);
                conc.Open();
                DataTable dt = new DataTable();
                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                conc.Close();
                if (dt.Rows.Count >= 0)
                {
                    DataList1.DataSource = dt;
                    DataList1.DataBind();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile && TextBox1.Text!="" && TextBox2.Text!="" && TextBox6.Text!="")
            {
                FileUpload1.SaveAs(Server.MapPath("~/SSN/") + Path.GetFileName(FileUpload1.FileName));
                SqlCommand cmd = new SqlCommand("insert into loantype(loan_code,loan_name,loan_description,photo)values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox6.Text + "','" + FileUpload1.FileName + "')", conc);
                conc.Open();
                cmd.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Loan Type Created');window.location='addloans.aspx'</script>");
            }
            else
            {

            }
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
          
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Label lbl = (Label)btn.NamingContainer.FindControl("Label1");

            if (lbl.Text != "")
            {
                SqlCommand cmd1 = new SqlCommand("delete from loantype where loan_code='" + lbl.Text + "'", conc);
                conc.Open();
                cmd1.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Loan Type Deleted');window.location='addloans.aspx' </script>");
            }
        }
    }
}