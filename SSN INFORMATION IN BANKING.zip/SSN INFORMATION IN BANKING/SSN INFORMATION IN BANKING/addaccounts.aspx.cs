﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class addaccounts : System.Web.UI.Page
    {

        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlCommand cmd = new SqlCommand("select * from accounttype", conc);
                conc.Open();
                DataTable dt = new DataTable();
                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                conc.Close();
                if (dt.Rows.Count >= 0)
                {
                    DataList1.DataSource = dt;
                    DataList1.DataBind();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text!="" && TextBox2.Text!="")
            {
               
                SqlCommand cmd = new SqlCommand("insert into accounttype(account_code,account_name)values('" + TextBox1.Text + "','" + TextBox2.Text + "')", conc);
                conc.Open();
                cmd.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Account Type Created');window.location='addaccounts.aspx'</script>");
            }
            else
            {

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Label lbl = (Label)btn.NamingContainer.FindControl("Label1");

            if (lbl.Text != "")
            {
                SqlCommand cmd1 = new SqlCommand("delete from accounttype where account_code='" + lbl.Text + "'", conc);
                conc.Open();
                cmd1.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Account Type Deleted');window.location='addaccounts.aspx' </script>");
            }
        }
    }
}