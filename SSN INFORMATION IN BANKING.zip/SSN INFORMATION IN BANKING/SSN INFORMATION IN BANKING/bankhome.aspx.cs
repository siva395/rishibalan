﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class bankhome : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlCommand cmd1 = new SqlCommand("select count(branch_code) as result from branch", conc);
                conc.Open();
                DataTable dt1 = new DataTable();
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                dt1.Load(sdr1);
                cmd1.ExecuteReader();
                conc.Close();
                if (dt1.Rows.Count > 0)
                {
                    Label1.Text = dt1.Rows[0]["result"].ToString();
                }

                SqlCommand cmd2 = new SqlCommand("select count(account_code) as result from accounttype", conc);
                conc.Open();
                DataTable dt2 = new DataTable();
                SqlDataReader sdr2 = cmd2.ExecuteReader();
                dt2.Load(sdr2);
                cmd2.ExecuteReader();
                conc.Close();
                if (dt2.Rows.Count > 0)
                {
                    Label2.Text = dt2.Rows[0]["result"].ToString();
                }

                SqlCommand cmd3 = new SqlCommand("select count(loan_code) as result from loantype", conc);
                conc.Open();
                DataTable dt3 = new DataTable();
                SqlDataReader sdr3 = cmd3.ExecuteReader();
                dt3.Load(sdr3);
                cmd3.ExecuteReader();
                conc.Close();
                if (dt3.Rows.Count > 0)
                {
                    Label3.Text = dt3.Rows[0]["result"].ToString();
                }

                SqlCommand cmd4 = new SqlCommand("select count(name) as result from accountholder", conc);
                conc.Open();
                DataTable dt4 = new DataTable();
                SqlDataReader sdr4 = cmd4.ExecuteReader();
                dt4.Load(sdr4);
                cmd4.ExecuteReader();
                conc.Close();
                if (dt4.Rows.Count > 0)
                {
                    Label4.Text = dt4.Rows[0]["result"].ToString();
                }

                SqlCommand cmd5 = new SqlCommand("select count(name) as result from loan_apply where flag='Approved'", conc);
                conc.Open();
                DataTable dt5 = new DataTable();
                SqlDataReader sdr5 = cmd5.ExecuteReader();
                dt5.Load(sdr5);
                cmd5.ExecuteReader();
                conc.Close();
                if (dt5.Rows.Count > 0)
                {
                    Label5.Text = dt5.Rows[0]["result"].ToString();
                }

                SqlCommand cmd6 = new SqlCommand("select count(name) as result from loan_apply where flag='Rejected'", conc);
                conc.Open();
                DataTable dt6 = new DataTable();
                SqlDataReader sdr6 = cmd6.ExecuteReader();
                dt6.Load(sdr6);
                cmd6.ExecuteReader();
                conc.Close();
                if (dt6.Rows.Count > 0)
                {
                    Label6.Text = dt6.Rows[0]["result"].ToString();
                }

                SqlCommand cmd7 = new SqlCommand("select count(name) as result from loan_apply where flag='Pending'", conc);
                conc.Open();
                DataTable dt7 = new DataTable();
                SqlDataReader sdr7 = cmd7.ExecuteReader();
                dt7.Load(sdr7);
                cmd7.ExecuteReader();
                conc.Close();
                if (dt7.Rows.Count > 0)
                {
                    Label7.Text = dt7.Rows[0]["result"].ToString();
                }
            }
            }
    }
}