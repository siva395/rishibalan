﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class transaction : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(TextBox7.Text!="")
            {

            int amt = Convert.ToInt32(TextBox4.Text);
            int tran_amt = Convert.ToInt32(TextBox7.Text);
           
                SqlCommand cmd = new SqlCommand("insert into transactions(name,acct_no,acct_type,avail_bal,trans_amt,transaction_mode,acct_date) values('" + TextBox3.Text + "','" + TextBox2.Text + "','"+TextBox5.Text+"'," + (amt+tran_amt) + ","+tran_amt+",'Deposit','" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "')", conc);
                conc.Open();
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand("update accountholder set amt="+(amt+tran_amt)+" where acct_no='"+TextBox2.Text+"'", conc);
                cmd1.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Amount Deposited Successfully');window.location='transaction.aspx'</script>");
            }
            else
            {
                Response.Write("<script>alert('Enter Amount for transaction')</script>");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            if (TextBox7.Text != "")
            {
                int amt = Convert.ToInt32(TextBox4.Text);
                int tran_amt = Convert.ToInt32(TextBox7.Text);
                if (amt >= tran_amt)
                {
                    SqlCommand cmd = new SqlCommand("insert into transactions(name,acct_no,acct_type,avail_bal,trans_amt,transaction_mode,acct_date) values('" + TextBox3.Text + "','" + TextBox2.Text + "','"+TextBox5.Text+"'," + (amt - tran_amt) + "," + tran_amt + ",'Withdraw','" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "')", conc);
                    conc.Open();
                    cmd.ExecuteNonQuery();
                    SqlCommand cmd1 = new SqlCommand("update accountholder set amt=" + (amt - tran_amt) + " where acct_no='" + TextBox2.Text + "'", conc);
                    cmd1.ExecuteNonQuery();
                    conc.Close();
                    Response.Write("<script>alert('Amount Withdrawn Successfully');window.location='transaction.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Insufficient Balance')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Enter Amount for transaction')</script>");
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text!="")
            {
                SqlCommand cmd1 = new SqlCommand("select * from transactions where acct_no='" + TextBox1.Text + "'", conc);
                conc.Open();
                DataTable dt1 = new DataTable();
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                dt1.Load(sdr1);
                conc.Close();
                if (dt1.Rows.Count >= 0)
                {
                    DataList2.DataSource = dt1;
                    DataList2.DataBind();
                }
            }
            else
            {
                Response.Write("<script>alert('Enter Account No.')</script>");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "")
            {

                SqlCommand cmd = new SqlCommand("select * from accountholder where acct_no='" + TextBox1.Text + "'", conc);
                conc.Open();
                DataTable dt = new DataTable();
                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                conc.Close();
                if (dt.Rows.Count > 0)
                {
                    TextBox3.Text = dt.Rows[0]["name"].ToString();
                    TextBox2.Text = dt.Rows[0]["acct_no"].ToString();
                    TextBox4.Text = dt.Rows[0]["amt"].ToString();
                    TextBox5.Text = dt.Rows[0]["acct_type"].ToString();


                }
            }
        }
    }
}