﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text=="admin" && TextBox2.Text=="admin@123")
            {
                Response.Redirect("ssnhome.aspx");
            }
            else if(TextBox1.Text=="bank" && TextBox2.Text=="bank@123")
            {
                Response.Redirect("bankhome.aspx");
            }
            else if (TextBox1.Text == "branch" && TextBox2.Text == "branch@123")
            {
                Response.Redirect("branchhome.aspx");
            }
            else
            {
                Response.Write("<script>('Login invalid')</script>");
            }
        }
    }
}