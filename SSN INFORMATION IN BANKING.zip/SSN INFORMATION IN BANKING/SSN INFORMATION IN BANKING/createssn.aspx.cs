﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class createssn : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            int genRand = r.Next(10000000, 900000000);
            TextBox1.Text = ("" + genRand);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                FileUpload1.SaveAs(Server.MapPath("~/SSN/") + Path.GetFileName(FileUpload1.FileName));
                SqlCommand cmd = new SqlCommand("insert into ssn_basic(ssn_number,name,father_name,mother_name,dob,gender,mobile,email,address,city,state,pincode,photo)values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + DropDownList1.SelectedItem + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','"+DropDownList2.SelectedItem+"','"+TextBox10.Text+"','" + FileUpload1.FileName + "')", conc);
                conc.Open();
                cmd.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Data Registered');window.location='createssn.aspx'</script>");
            }
            else
            {

            }
        }
    }
}