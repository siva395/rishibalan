﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
   
    public partial class createloan : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            int genRand = r.Next(10000000, 900000000);
            TextBox15.Text = ("" + genRand);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "")
            {
                SqlCommand cmd = new SqlCommand("select *,('/SSN/')+photo as img from ssn_basic where ssn_number='" + TextBox1.Text + "'", conc);
                conc.Open();
                DataTable dt = new DataTable();
                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                conc.Close();
                if (dt.Rows.Count > 0)
                {
                    TextBox3.Text = dt.Rows[0]["name"].ToString();
                    TextBox14.Text = dt.Rows[0]["name"].ToString();
                    TextBox4.Text = dt.Rows[0]["father_name"].ToString();
                    TextBox5.Text = dt.Rows[0]["mother_name"].ToString();
                    TextBox6.Text = dt.Rows[0]["dob"].ToString();
                    TextBox12.Text = dt.Rows[0]["gender"].ToString();
                    TextBox8.Text = dt.Rows[0]["mobile"].ToString();
                    TextBox9.Text = dt.Rows[0]["email"].ToString();
                    TextBox7.Text = dt.Rows[0]["address"].ToString();
                    TextBox10.Text = dt.Rows[0]["city"].ToString();
                    TextBox2.Text = dt.Rows[0]["state"].ToString();
                    TextBox11.Text = dt.Rows[0]["pincode"].ToString();
                    Image1.ImageUrl = dt.Rows[0]["img"].ToString();
                }

                SqlCommand cmd1 = new SqlCommand("select *,('/Proof/')+photo as img from ssn_proof where ssn_number='" + TextBox1.Text + "'", conc);
                conc.Open();
                DataTable dt1 = new DataTable();
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                dt1.Load(sdr1);
                conc.Close();
                if (dt1.Rows.Count >= 0)
                {
                    DataList2.DataSource = dt1;
                    DataList2.DataBind();
                }
            }
            else
            {

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox14.Text != "" && TextBox17.Text != "" && TextBox18.Text != "" && TextBox7.Text != "" && TextBox8.Text != "" && TextBox9.Text != "" && FileUpload2.HasFile)
            {
                SqlCommand checkdata = new SqlCommand("select count(*) from loan_apply where ssn_number='" + TextBox1.Text + "' and loan_type='" + DropDownList1.SelectedItem + "'", conc);
                conc.Open();
                int count = Convert.ToInt32(checkdata.ExecuteScalar());
                conc.Close();
                if (count == 0)
                {
                    FileUpload2.SaveAs(Server.MapPath("~/SSN/") + Path.GetFileName(FileUpload2.FileName));
                    SqlCommand cmd = new SqlCommand("insert into loan_apply(ssn_number,name,gender,mobile,email,address,loan_no,loan_type,pan_no,amt,duration,proof,loan_date,flag)values('" + TextBox1.Text + "','" + TextBox14.Text + "','" + TextBox12.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + TextBox7.Text + "','" + TextBox15.Text + "','" + DropDownList1.SelectedItem + "','" + TextBox17.Text + "','" + TextBox18.Text + "'," + DropDownList2.SelectedItem + ",'" + FileUpload2.FileName + "','" + DateTime.Now.ToString() + "','Pending')", conc);
                    conc.Open();
                    cmd.ExecuteNonQuery();
                    conc.Close();
                    Response.Write("<script>alert('Data Registered');window.location='createloan.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('User already has applied loan on this Loan type')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Fill all fields')</script>");
            }
        }
    }
}