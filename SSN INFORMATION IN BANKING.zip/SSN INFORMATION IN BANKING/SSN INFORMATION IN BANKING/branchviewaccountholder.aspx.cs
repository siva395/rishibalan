﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class branchviewaccountholder : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlCommand cmd1 = new SqlCommand("select * from accountholder", conc);
            conc.Open();
            DataTable dt1 = new DataTable();
            SqlDataReader sdr1 = cmd1.ExecuteReader();
            dt1.Load(sdr1);
            conc.Close();
            if (dt1.Rows.Count >= 0)
            {
                DataList1.DataSource = dt1;
                DataList1.DataBind();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "")
            {
                SqlCommand cmd1 = new SqlCommand("select * from accountholder where ssn_number='" + TextBox1.Text + "' or acct_no='" + TextBox1.Text + "'", conc);
                conc.Open();
                DataTable dt1 = new DataTable();
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                dt1.Load(sdr1);
                conc.Close();
                if (dt1.Rows.Count >= 0)
                {
                    DataList1.DataSource = dt1;
                    DataList1.DataBind();
                }
            }
            else
            {

            }
        }
    }
}