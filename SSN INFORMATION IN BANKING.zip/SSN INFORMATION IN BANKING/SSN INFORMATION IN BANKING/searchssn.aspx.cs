﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class searchssn : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(TextBox1.Text!="")
            {
                    SqlCommand cmd = new SqlCommand("select *,('/SSN/')+photo as img from ssn_basic where ssn_number='" + TextBox1.Text + "'", conc);
                    conc.Open();
                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dt.Load(sdr);
                    conc.Close();
                    if (dt.Rows.Count > 0)
                    {
                    TextBox13.Text = dt.Rows[0]["ssn_number"].ToString();
                    TextBox3.Text = dt.Rows[0]["name"].ToString();
                        TextBox4.Text = dt.Rows[0]["father_name"].ToString();
                        TextBox5.Text = dt.Rows[0]["mother_name"].ToString();
                        TextBox6.Text = dt.Rows[0]["dob"].ToString();
                        TextBox12.Text = dt.Rows[0]["gender"].ToString();
                        TextBox8.Text = dt.Rows[0]["mobile"].ToString();
                        TextBox9.Text = dt.Rows[0]["email"].ToString();
                        TextBox7.Text = dt.Rows[0]["address"].ToString();
                        TextBox10.Text = dt.Rows[0]["city"].ToString();
                        TextBox2.Text = dt.Rows[0]["state"].ToString();
                        TextBox11.Text = dt.Rows[0]["pincode"].ToString();
                        Image1.ImageUrl = dt.Rows[0]["img"].ToString();


                    }

                    SqlCommand cmd1 = new SqlCommand("select *,('/Proof/')+photo as img from ssn_proof where ssn_number='" + TextBox1.Text + "'", conc);
                conc.Open();
                DataTable dt1 = new DataTable();
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                dt1.Load(sdr1);
                conc.Close();
                if (dt1.Rows.Count >= 0)
                {
                    DataList2.DataSource = dt1;
                    DataList2.DataBind();
                }
            }
            else
            {
                Response.Write("<script>alert('Enter SSN Number to search')</script>");
            }
           
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            if(TextBox2.Text!="" && TextBox7.Text != "" && TextBox8.Text != "" && TextBox9.Text != "" && TextBox10.Text != "" && TextBox11.Text != "" )
            {
                SqlCommand cmd1 = new SqlCommand("update ssn_basic set mobile="+TextBox8.Text+", email='"+TextBox9.Text+"',address='"+TextBox7.Text+"',city='"+TextBox10.Text+"',state='"+TextBox2.Text+"',pincode="+TextBox11.Text+" where ssn_number='" + TextBox13.Text + "'", conc);
                conc.Open();
                cmd1.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Updated Successfully') </script>");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Label lbl = (Label)btn.NamingContainer.FindControl("Label3");
            Label lblssn = (Label)btn.NamingContainer.FindControl("Label1");
            if (lbl.Text!="")
            {
                SqlCommand cmd1 = new SqlCommand("delete from ssn_proof where card_no='"+lbl.Text+"' and ssn_number='"+lblssn.Text+"'", conc);
                conc.Open();
                cmd1.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Deleted Successfully') </script>");
            }
           // Label lbl1 = btn.NamingContainer.FindControl("Label3");

        }
    }
}