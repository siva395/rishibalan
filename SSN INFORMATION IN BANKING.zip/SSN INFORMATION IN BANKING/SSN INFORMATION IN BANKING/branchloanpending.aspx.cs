﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SSN_INFORMATION_IN_BANKING
{
    public partial class branchloanpending : System.Web.UI.Page
    {
        SqlConnection conc = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            { 
            SqlCommand cmd = new SqlCommand("select *,('/SSN/')+proof as img from loan_apply where flag='Pending'", conc);
            conc.Open();
            DataTable dt = new DataTable();
            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            conc.Close();
            if (dt.Rows.Count >= 0)
            {
                DataList1.DataSource = dt;
                DataList1.DataBind();
            }
        }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "")
            {
                SqlCommand cmd = new SqlCommand("select *,('/SSN/')+proof as img from loan_apply where flag='Pending' and loan_no='" + TextBox1.Text + "'", conc);
                conc.Open();
                DataTable dt = new DataTable();
                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                conc.Close();
                if (dt.Rows.Count >= 0)
                {
                    DataList1.DataSource = dt;
                    DataList1.DataBind();
                }
            }
            else
            {

            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            
            Button btn = (Button)sender;
            Label lbl = (Label)btn.NamingContainer.FindControl("Label9");
            Label lblssn = (Label)btn.NamingContainer.FindControl("Label1");
            if (lbl.Text != "")
            {
                SqlCommand cmd1 = new SqlCommand("update loan_apply set flag='Approved' where loan_no='" + lbl.Text + "' and ssn_number='" + lblssn.Text + "'", conc);
                conc.Open();
                cmd1.ExecuteNonQuery();
                conc.Close();
                Response.Write("<script>alert('Loan Approved');window.location='branchloanpending.aspx' </script>");
            }
        
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
                Button btn = (Button)sender;
                Label lbl = (Label)btn.NamingContainer.FindControl("Label9");
                Label lblssn = (Label)btn.NamingContainer.FindControl("Label1");
                if (lbl.Text != "")
                {
                    SqlCommand cmd1 = new SqlCommand("update loan_apply set flag='Rejected' where loan_no='" + lbl.Text + "' and ssn_number='" + lblssn.Text + "'", conc);
                    conc.Open();
                    cmd1.ExecuteNonQuery();
                    conc.Close();
                    Response.Write("<script>alert('Loan Rejected');window.location='branchloanpending.aspx' </script>");
                }
            
        }
    }
}